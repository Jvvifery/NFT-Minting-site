<?php

$config = [
	'name'              => __('Date', 'rishi'),
	'visibilityKey'     => 'header_hide_date',
	'typography_keys'   => ['headerDateFont'],
	'selective_refresh' => ['header_date_ed_icon', 'header_date_format_custom'],
];
