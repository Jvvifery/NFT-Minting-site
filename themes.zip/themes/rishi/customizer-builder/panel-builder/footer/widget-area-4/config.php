<?php

$config = [
    'name' => __('Widget 4', 'rishi'),
    'visibilityKey' => 'footer_hide_widget_four',
    // 'clone' => true,
];
