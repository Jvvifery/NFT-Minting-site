<?php

$config = [
	'name' => __('Middle Row', 'rishi'),
	'typography_keys' => ['footerWidgetsTitleFont', 'footerWidgetsFont'],
];
